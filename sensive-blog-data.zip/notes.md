Донор постов — [блог](https://www.franksonnenbergonline.com/) Франка Сонненберга.
